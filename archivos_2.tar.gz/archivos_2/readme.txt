¡Gran trabajo, campeón/a! 
Dominaste los comandos como un experto.
Linux es un mundo lleno de oportunidades.
¡Sigue explorando y rompiendo límites! 